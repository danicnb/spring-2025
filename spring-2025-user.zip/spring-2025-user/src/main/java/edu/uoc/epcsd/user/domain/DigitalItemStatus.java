package edu.uoc.epcsd.user.domain;

public enum DigitalItemStatus {

    AVAILABLE,
	NOT_AVAILABLE,
    REVIEW_PENDING;

}
